﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InnoApp.Controllers
{
    public abstract class TipoContrato
    {
        public abstract long Salario(long val);
    }
}