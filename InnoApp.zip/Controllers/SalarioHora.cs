﻿using InnoApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InnoApp.Controllers
{
    public class SalarioHora: TipoContrato
    {
        long total;
        public override long Salario(long val)
        {
            Contact c = new Contact();
            total = 120 *val  * 12;
            return total;
           
        }
    }
}