﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InnoApp.Controllers
{
    public class Salario
    {
        public const int Salario_Hora = 1;
        public const int Salario_Mensual = 2;

        public static TipoContrato Salarios(int tipo)
        {
            switch (tipo)
            {
                case Salario_Hora:
                    return new SalarioHora();
                case Salario_Mensual:
                    return new SalarioMensual();
                default: return null;
            }
        }
    }
}