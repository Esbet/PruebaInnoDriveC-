﻿using InnoApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InnoApp.Controllers
{
    public class SalarioMensual:TipoContrato
    {
        long total;
        public override long Salario(long val)
        {
           
            total = val* 12;
            return total;
        }
    }
}