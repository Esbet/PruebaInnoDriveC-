﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.Threading.Tasks;
using Agenda_Example_MVC.Models;
using InnoApp.Models;
using InnoApp.Controllers;

namespace Agenda_Example_MVC.Controllers
{
    public class ContactsController : Controller
    {
        ContactModel model;
  
        public ContactsController()
        {
            this.model = new ContactModel();
         
        }
        // GET: 
        
        public async Task<ActionResult> Index(string textbox1, string textbox2)
        {
            if (textbox1!= null && textbox2 !=null )
            {
                TipoContrato val = Salario.Salarios(Salario.Salario_Hora);
                TipoContrato val2 = Salario.Salarios(Salario.Salario_Mensual);

                ViewBag.Message = "Salario anual por hora es: $" + val.Salario(long.Parse(textbox1));
                ViewBag.Message2= "Salario anual por mes es: $" + val2.Salario(long.Parse(textbox2));
            }
            else
            {
                ViewBag.Message3 = "Debes ingresar los valores correspondientes";
            }
            


            List<Contact> cList = await model.GetContacts();
            return View(cList);
        }
      


     

      
    

       
    }
}
