﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InnoApp.Models
{
    public class Contact
    {
        public int id { get; set; }
        public string name { get; set; }
        public string contractTypeName { get; set; }
        public int roleId { get; set; }
        public string roleName { get; set; }
        public string roleDescripcion { get; set; }
        public long hourlySalary { get; set; }
        public long monthlySalary { get; set; }
     
      




    }
 

   
}